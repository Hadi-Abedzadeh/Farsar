<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('frontend.blog.index') .'/'.$post->slug); ?>"><?php echo e($post->title); ?></a>
        <br>
        <?php echo str_limit(strip_tags($post->body), 70); ?>

        <?php echo (strlen(strip_tags($post->body)) > 70) ? ' ...... ' : ''; ?>



        <ul>
            <?php $__currentLoopData = $post->categories()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('category', ['category' => $category])); ?>"> <?php echo e($category); ?> </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($blog_posts->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>