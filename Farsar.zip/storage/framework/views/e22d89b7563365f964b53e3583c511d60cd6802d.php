<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='col-lg-3'>
            <div class='panel panel-default'>
                <div class='panel-heading'><h3><?php echo e($product->title); ?></h3></div>
                <div class='panel-body'>
                    <?php echo e($product->body); ?>

                </div>
                <div class='panel-footer'>
                    <a href="<?php echo e(route('frontend.product.show', ['slug' => $product->slug])); ?>">See more</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('default.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>