<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Blog</h2>
    <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well ">
                <?php if(file_exists(($post->imageUrl))): ?>
                    <img src="/<?php echo e($post->imageUrl); ?>"
                         style="width: 100%; height: 300px; border-radius: 2px">
                <?php else: ?>
                    <img src="/uploads/no-image.png" style="width: 100%; height: 300px; border-radius: 2px">
                <?php endif; ?>
                <br>

                <h2><a href="<?php echo e(route('frontend.blog.index') .'/'.$post->slug); ?>"><?php echo e($post->title); ?></a></h2>
                <br>
                <?php echo str_limit(strip_tags($post->body), 300); ?>

                <?php echo (strlen(strip_tags($post->body)) > 300) ? ' ...... ' : ''; ?>

                <br>
                <hr>

                    <?php if(count($post->categories()->get())): ?>
                    <ul>Category:
                        <?php $__currentLoopData = $post->categories()->pluck('name', 'slug'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('category', ['categorySlug' => $slug])); ?>"> <?php echo e($category); ?> </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                        <?php else: ?>
                        <?php echo e("Has no category"); ?>

                    <?php endif; ?>
                <hr>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($blog_posts->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>