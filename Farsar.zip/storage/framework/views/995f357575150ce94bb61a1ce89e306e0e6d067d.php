<?php $__env->startSection('content'); ?>
    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project">
                <header>
                    <h3 class="c-h2">
                        لیست <em class="f-c-b">پروژه ها</em>
                    </h3>
                </header>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="art-slider-content-project slidert-<?php echo e($loop->iteration); ?>">
                        <div class="swiper-container swiper-slider-project">
                            <bdi class="bdi-arrow-slider-project next f-c-b"><i
                                class="icon-next swiper-project swiper-project-next"></i></bdi>
                                <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <figure class="fig-img-project">
                                        <img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/project/2.png" alt=""
                                             title="" class="swiper-lazy">
                                    </figure>
                                </div>

                                <?php $__currentLoopData = json_decode($project->imageUrls, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <figure class="fig-img-project">
                                            <img data-src="<?php echo e($img); ?>" alt="" title="" class="swiper-lazy">
                                        </figure>
                                        <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <bdi class="bdi-arrow-slider-project prev f-c-b"><i
                                    class="icon-prev swiper-project swiper-project-prev"></i></bdi>
                        </div>
                        <div class="div-content-slider">
                            <header>
                                <h2 class="c-h2">
                                    پروژه <em class="f-c-b"><?php echo e($project->title); ?></em>
                                </h2>
                            </header>
                            <P class="c-p">
                                <?php echo e(substr(strip_tags($project->body), 0, 500)); ?>

                                <?php echo e(strlen(strip_tags($project->body)) > 50 ? "..." : ""); ?>

                            </P>
                            <a class="a-btn-bggr a-btn a-btn-bggr-product" href="<?php echo e(route('frontend.project.show', ['slug' => $project->slug])); ?>" title="اطلاعات بیشتر">اطلاعات بیشتر</a>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    پروژه ها
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>