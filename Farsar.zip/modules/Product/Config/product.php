<?php

return [
    'name' => 'Product'
];