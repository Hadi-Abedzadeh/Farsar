<?php

return [
    'name' => 'Project'
];