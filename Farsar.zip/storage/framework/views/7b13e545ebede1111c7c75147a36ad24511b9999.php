<?php $__env->startSection('content'); ?>

    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-any-blog">
                <div class="row p15">
                    <div class="col-md-24">
                        <article class="art-content-about">
                            <div class="div-content-about">
                                </header>
                                <p class="c-p">
                                    <?php echo $about->body; ?>

                                </p>
                            </div>
                        </article>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <section class="sec-slider-product sec-slider-about">
        <div class="container">
            <div class="swiper-container slider-product">
                <div class="swiper-wrapper">
                    <?php echo e(create_box_honors(6)); ?>

                </div>
            </div>
        </div>
        <i class="icon-next swiper-product swiper-product-next f-c-b"></i>
        <i class="icon-prev swiper-product swiper-product-prev f-c-b"></i>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    درباره ما
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>