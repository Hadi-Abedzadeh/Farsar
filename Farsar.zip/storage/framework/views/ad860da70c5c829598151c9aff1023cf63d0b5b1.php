<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="innerarea">
            <div class="category">
                <div class="areaheader">
                    <h2>Categories</h2>
                </div>
                <div class="categorylist">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('category', ['slug'=> $category->slug ])); ?>"><?php echo e($category->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="content">
                <div class="areaheader">
                    <h2>Blog</h2>
                    <div class="sorter">
                        <div class="sorterheader">Newest</div>
                        <span>Newest</span>
                        <span>Oldest</span>
                    </div>
                </div>
                <div class="blogposts">
                    <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blogpost">
                            <div class="blogpostimg">
                                <img src="<?php echo e($post->imageUrl); ?>" draggable="false">
                            </div>
                            <div class="blogpostcontent">
                                <h4><?php echo e($post->title); ?></h4>
                                <p>
                                    <?php echo e(substr(strip_tags($post->body), 0, 100)); ?>

                                    <?php echo e(strlen(strip_tags($post->body)) > 50 ? "..." : ""); ?>

                                </p>
                                <a href="<?php echo e(route('frontend.blog.index.slug', ['slug' => $post->slug ])); ?>" class="more">See More</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <?php echo e($blog_posts->links()); ?>

                
                    
                    
                    
                    
                    
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Blog
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>