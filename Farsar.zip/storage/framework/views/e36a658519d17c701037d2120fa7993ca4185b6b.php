<?php $__env->startSection('content'); ?>

    <div id="fullpage">
        <div class="section header">
            <?php echo create_box_first(1); ?>

        </div>
        <div class="section products">
            <div class="sectionheader">
                <h2>OUR <span>PRODUCTS</span></h2>
                <h3>WHAT WE MAKE?</h3>
            </div>
            <div class="container">
                <?php echo e(create_box_second(2)); ?>

            </div>
            <a href="#" class="seealllink"><span>SEE ALL PRODUCTS</span></a>
        </div>
        <div class="section news">
            <div class="sectionheader">
                <h2>OUR <span>NEWS</span></h2>
                <h3>WHAT’S UP?</h3>
            </div>
            <div class="container">
                <?php echo e(create_box_news(3)); ?>



            </div>
            <a href="#" class="seealllink"><span>SEE ALL NEWS</span></a>
        </div>
        <div class="section footer">
            <div class="sectionheader">
                <h2><span>CONTACT</span> US</h2>
                <h3>HOW TELL TO US?</h3>
            </div>
            <div class="footercontent">
                <?php echo $contact->etc; ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.fullpage-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>