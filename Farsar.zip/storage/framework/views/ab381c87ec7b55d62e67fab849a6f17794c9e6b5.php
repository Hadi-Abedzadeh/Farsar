<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="singlecontent">
            <div class="sectionheader">
                <h2><span>ABOUT</span> US</h2>
                <h3>WHO WE ARE?</h3>
            </div>
            <p>
                <?php echo $about->body; ?>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>