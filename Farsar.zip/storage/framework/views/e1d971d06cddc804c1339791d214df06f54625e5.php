<?php $__env->startSection('title'); ?>
    Contact-us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet m-portlet--full-height m-portlet--fit ">
        <div class="m-portlet__body">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <form action="<?php echo e(route('contact-us.update', ['id' => 1])); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>


                <div class="form-group">
                    <label for="map_location">Map location</label>
                    <input type="text" name="map_location" value="<?php echo e($contact->map_location); ?>" class="form-control"
                           id="map_location" placeholder="Location">
                </div>

                <div class="form-group">
                    <label for="social_media">Social media's</label>
                    <input class="form-control" name="social_media" value="<?php echo e($contact->social_media); ?>"
                           id="social_media" placeholder="Social Media's">
                </div>

                <div class="form-group">

                    <div class="row">
                        <div class="col-lg-2">
                            <label for="social_media">Facebook</label>
                            <input type="text" class="form-control" value="<?php echo e(isset($social->facebook)); ?>" name="facebook">
                        </div>

                        <div class="col-lg-2">
                            <label for="social_media">Instagram</label>
                            <input type="text" class="form-control" value="<?php echo e(isset($social->instagram)); ?>" name="instagram">
                        </div>

                        <div class="col-lg-2">
                            <label for="social_media">Twitter</label>
                            <input type="text" class="form-control" value="<?php echo e(isset($social->twitter)); ?>" name="twitter">
                        </div>

                    </div>
                </div>

                <div class="form-group">
                    <label for="etc">Address, tell ... </label>
                    <textarea class="form-control" name="etc" id="etc">
                        <?php echo $contact->etc; ?>

                    </textarea>
                </div>

                <input type="hidden" name="id" value="1">

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>

            <script src="/assets/ckeditor/ckeditor.js"></script>
            <script>
                CKEDITOR.replace('etc');
            </script>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>