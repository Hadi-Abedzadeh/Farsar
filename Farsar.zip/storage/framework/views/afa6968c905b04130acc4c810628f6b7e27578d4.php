<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='col-md-3'>
            <div class='card mb-3 box-shadow'>
                <h3><?php echo e($project->title); ?></h3>
                <div class='card-body'>
                    <p class='card-text'>
                    <?php echo e($project->body); ?>


                    <div>
                        <a href="<?php echo e(route('frontend.project.show', ['id' => $project->id])); ?>">تمام پروژه ها</a>
                    </div>
                    </p>
                    <div class='d-flex justify-content-between align-items-center'>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('default.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>