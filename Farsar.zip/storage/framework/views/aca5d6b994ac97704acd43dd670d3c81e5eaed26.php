<?php $__env->startSection('content'); ?>

    <div class="singleheader">
        <div class="singlecover"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/background.jpg"></div>
        <a href="<?php echo e(route('frontend.product.index')); ?>" class="singleback">BACK TO PRODUCTS</a>
    </div>
    <div class="singleheaderclear"></div>
    <div class="container-fluid">
        <div class="singlecontent">
            <h1><?php echo e($product_list->title); ?></h1>
            <p><?php echo e($product_list->body); ?></p>
        </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>