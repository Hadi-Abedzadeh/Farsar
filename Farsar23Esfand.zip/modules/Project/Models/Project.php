<?php

namespace Modules\Project\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{

}
