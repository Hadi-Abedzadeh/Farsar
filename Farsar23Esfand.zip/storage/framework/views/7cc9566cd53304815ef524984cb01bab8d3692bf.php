<div class="footernav">
    <a href="<?php echo e(route('frontend')); ?>">Home</a>
    <a href="<?php echo e(route('aboutus')); ?>">About</a>
    <a href="<?php echo e(route('frontend.project.index')); ?>">Projects</a>
    <a href="<?php echo e(route('frontend.news.index')); ?>">News</a>
    <a href="<?php echo e(route('frontend.product.index')); ?>">Products</a>
    <a href="<?php echo e(route('frontend.blog.index')); ?>">Blog</a>
</div>
