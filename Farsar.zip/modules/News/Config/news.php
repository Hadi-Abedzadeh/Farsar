<?php

return [
    'name' => 'News'
];