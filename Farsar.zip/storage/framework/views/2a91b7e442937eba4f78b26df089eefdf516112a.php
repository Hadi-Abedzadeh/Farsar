<?php $__env->startSection('content'); ?>
Backend index page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>