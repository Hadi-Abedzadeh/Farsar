<?php

return [
    'name' => 'Blog'
];