<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <article class="art-content-faq">
                <header>

                                        <span class="bdi-bg-c">
                                            <i class="num"><?php echo e($loop->iteration); ?></i>
                                            <i class="mi"></i>
                                        </span>
                    <h3 class="c-h2"><?php echo e($q->question); ?></h3>
                </header>
                <p class="p-b-c"><?php echo e($q->answer); ?></p>
            </article>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>