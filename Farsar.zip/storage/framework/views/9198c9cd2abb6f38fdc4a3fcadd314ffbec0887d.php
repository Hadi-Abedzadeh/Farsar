<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h2>News</h2>

    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='col-lg-3'>
            <div class='panel panel-default'>
                <div class='panel-heading'>
                    <h3>
                        <a href="<?php echo e(route('frontend.news.index.show', ['slug' => $report->slug ])); ?>"><?php echo e($report->title); ?></a>
                    </h3>
                </div>
                <div class='panel-body'>
                    <?php echo str_limit(strip_tags($report->body), 70); ?>

                    <?php echo (strlen(strip_tags($report->body)) > 70) ? ' ...... ' : ''; ?>

                </div>
                <div class='panel-footer'>
                    <a href="<?php echo e(route('frontend.product.show', ['id' => $report->id])); ?>">See more</a>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($news->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('default.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>