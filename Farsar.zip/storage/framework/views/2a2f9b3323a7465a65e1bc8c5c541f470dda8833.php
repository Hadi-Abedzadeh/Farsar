<?php $__env->startSection('content'); ?>

<div class="div-list-project">
    <div class="container">
        <section class="sect-slider-content-project sect-slider-content-catalog sect-slider-content-blog">
            <header>
                <h2 class="c-h2">
                     <em class="f-c-b">بلاگ</em>
                </h2>
            </header>
            <div class="row p20">
                <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-8">
                    <article class="art-content-blog">
                        <figure>
                            <img class="img-blog " src="<?php echo e($post->imageUrl); ?>" alt="" title="">
                            <img class="img-before " src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/blogs.svg" alt="" title="">
                            <img class="img-before-c " src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/blogsc.svg" alt="" title="">
                        </figure>
                        <header>
                            <h3 class="f-c-b"><?php echo e($post->title); ?></h3>
                        </header>
                        <p class="c-p">
                            <?php echo e(substr(strip_tags($post->body), 0, 500)); ?>

                            <?php echo e(strlen(strip_tags($post->body)) > 50 ? "..." : ""); ?>

                        </p>
                        <a class="a-btn-bggr a-btn a-btn-blog" href="<?php echo e(route('frontend.blog.index.slug', ['slug' => $post->slug ])); ?>" title="اطلاعات بیشتر">اطلاعات
                            بیشتر</a>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        
            
        
    </div>

    <section class="sec-slider-product sec-slider-blog">
        <header>
            <h2 class="c-h2">
                برخی از <em class="f-c-b">محصولات</em>
            </h2>
        </header>
        <div class="container">
            <div class="swiper-container slider-product">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $same_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <article class="art-content-blog art-content-slider-blog">
                            <figure>
                                <img class="img-blog " src="<?php echo e(json_decode($same_product->imageUrls)->img1); ?>" alt="" title="">
                                <img class="img-before " src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/blogs.svg" alt="" title="">
                                <img class="img-before-c " src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/blogsc.svg" alt="" title="">
                            </figure>
                            <header>
                                <h3 class="f-c-b"><?php echo e($same_product->title); ?></h3>
                            </header>
                            <p class="c-p">
                                <?php echo e(substr(strip_tags($same_product->body), 0, 200)); ?>

                                <?php echo e(strlen(strip_tags($same_product->body)) > 200 ? "..." : ""); ?>

                            </p>
                            <a class="a-btn-bggr a-btn a-btn-blog" href="<?php echo e(route('frontend.product.show', ['slug' => $same_product->slug])); ?>" title="اطلاعات بیشتر">اطلاعات
                                بیشتر</a>
                        </article>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <i class="icon-next swiper-product swiper-product-next f-c-b"></i>
        <i class="icon-prev swiper-product swiper-product-prev f-c-b"></i>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
بلاگ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>