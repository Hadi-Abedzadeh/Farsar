<?php

return [
    'name' => 'Faq'
];