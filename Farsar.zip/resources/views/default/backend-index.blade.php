@extends('default.layouts.backend')

@section('content')
Backend index page
@endsection
