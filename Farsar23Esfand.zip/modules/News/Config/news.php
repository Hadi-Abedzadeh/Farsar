<?php

return [
    'name' => 'News'
];