<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="singleheader">
            <h3 class="singletitle"><?php echo e($post->title); ?></h3>
            <img src="<?php echo e($post->imageUrl); ?>" draggable="false">
        </div>
        <div class="singlecontent">
            <p>
                <?php echo e($post->body); ?>

            </p>
        </div>
        <?php if($tags->count() > 0): ?>
            <div class="singletags">

                <span>Tags: </span>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tag.show', ['slug' => $tag->slug])); ?>"><?php echo e($tag->name); ?></a>
                    <?php if(!$loop->last): ?> ,<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <br>

        <div class="newsitems singleslider owl-carousel">


            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="newsitem">
                    <div class="newsitemimg"><img src="<?php echo e($s->imageUrl); ?>" draggable="false"></div>
                    <div class="newsitemcontainer">
                        <h4><?php echo e($s->title); ?></h4>
                        <p>
                            <?php echo e(substr(strip_tags($s->body), 0, 200)); ?>

                            <?php echo e(strlen(strip_tags($s->body)) > 50 ? "..." : ""); ?>

                        </p>
                        <div class="newsitemfooter">
                            <a href="<?php echo e(route('frontend.blog.index.slug', ['slug' => $s->slug ])); ?>" class="more">See More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Blog
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>