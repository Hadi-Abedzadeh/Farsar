<?php $__env->startSection('content'); ?>
    <main id="catalog-page">
    <div class="container">
        <section class="catalog-section">
            <div class="title">
                <h2><span>کاتالوگ</span> ها</h2>
                <span>دانلود کاتالوگ محصولات</span>
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-24">
                        <a href="#">
                            <div class="item">
                                <div class="download icon"></div>
                                <div class="download text"><h5>کاتالوگ شماره یک </h5>
                                    <span>توضیحات مربوط به این کاتالوگ</span></div>
                                <div class="download date"><span>۳۱</span><span>شهریور</span></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    گاتالوگ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-fa.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>