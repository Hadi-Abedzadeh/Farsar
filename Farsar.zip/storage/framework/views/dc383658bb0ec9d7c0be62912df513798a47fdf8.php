<!doctype html>
<html>
<head>

    <meta charset="utf-8">
    <title>SFM | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/latest/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/latest/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/animate.css" type="text/css" media="screen">
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/fullpage.min.css" type="text/css" media="screen">
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/style.css" type="text/css" media="screen">
</head>
<body>

<?php echo $__env->make(env('THEME_NAME').'.frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="fullpage">

    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/fullpage.min.js"></script>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/plugin.js"></script>
</html>
