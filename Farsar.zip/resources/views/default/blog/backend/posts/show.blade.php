@extends('layouts.backend')

@section('content')
{{--{{ $blog_post->comments() }}--}}
@endsection
