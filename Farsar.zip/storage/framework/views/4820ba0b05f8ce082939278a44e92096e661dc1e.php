<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="gallerysliderarea owl-carousel">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="galleryslider">
                    <img src="<?php echo e(json_decode($product->imageUrls)->img1); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="innerarea">
            
                
                    
                
                
                    
                        
                    
                
            
            <div class="content">
                <div class="areaheader">
                    <h2>Products</h2>
                    <div class="sorter">
                        <div class="sorterheader">Newest</div>
                        <span>Newest</span>
                        <span>Oldest</span>
                    </div>
                </div>
                <div class="productitems">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="productitem">
                            <h3><?php echo e($product->title); ?></h3>
                            <div class="productitemimg">
                                <img src="<?php echo e(json_decode($product->imageUrls)->img1); ?>" draggable="false">
                                <img src="<?php echo e(json_decode($product->imageUrls)->img1); ?>" draggable="false">
                            </div>
                            <a href="<?php echo e(route('frontend.product.show', ['slug' => $product->slug])); ?>" class="getmore">Get
                                Order</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <?php echo e($products->links()); ?>

                
                
                
                
                
                
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>