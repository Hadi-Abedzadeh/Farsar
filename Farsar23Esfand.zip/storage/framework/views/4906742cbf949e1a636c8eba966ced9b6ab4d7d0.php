<ul>
    <li><a href="<?php echo e(route('frontend')); ?>" title="خانه">خانه</a></li>
    <li><a href="<?php echo e(route('aboutus')); ?>" title="درباره ما">درباره ما</a></li>
    <li><a href="<?php echo e(route('frontend.news.index')); ?>" title="اخبار">اخبار</a></li>
    <li><a href="<?php echo e(route('frontend.product.index')); ?>" title="محصولات">محصولات</a></li>
    <li><a href="<?php echo e(route('frontend.project.index')); ?>" title="پروژه ها">پروژه ها</a></li>
    <li><a href="<?php echo e(route('frontend.blog.index')); ?>" title="بلاگ">بلاگ</a></li>
    <li><a href="<?php echo e(route('catalog')); ?>" title="کاتالوگ">کاتالوگ</a></li>
    <li><a href="<?php echo e(route('contactus')); ?>" title="تماس با ما">تماس با ما</a></li>
</ul>
