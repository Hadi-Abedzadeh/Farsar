<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="innerarea sidebyside">
            <div class="singleside">
                <h4>Product Related</h4>

                <?php $__currentLoopData = $same_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $same_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="projectitem">
                        <h3><?php echo e($same_products->title); ?></h3>
                        <div class="projectitemimg">
                            <img src="<?php echo json_decode($same_products->imageUrls)->img1; ?>" draggable="false">
                            <a href="<?php echo e(route('frontend.product.show', ['slug'=>$same_products->slug])); ?>"
                               class="getmore">Get Order</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="singlearea">
                <h4>
                    <?php echo e($product_list->title); ?>

                </h4>

                <div class="gallerysliderarea owl-carousel">
                    <?php $__currentLoopData = json_decode($product_list->imageUrls); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="galleryslider active">
                            <img src="<?php echo e($img); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="content">
                    <p>
                        <?php echo e($product_list->body); ?>

                    </p>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>