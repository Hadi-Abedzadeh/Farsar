<?php $__env->startSection('content'); ?>

        <div class="section header">
            <?php echo create_box_first(1); ?>

        </div>
        <div class="section products">
            <div class="sectionheader">
                <h2>OUR <span>PRODUCTS</span></h2>
                <h3>WHAT WE MAKE?</h3>
            </div>
            <div class="container">
                <?php echo e(create_box_second(2)); ?>

            </div>
            <a href="<?php echo e(route('frontend.product.index')); ?>" class="seealllink"><span>SEE ALL PRODUCTS</span></a>
        </div>
        <div class="section news">
            <div class="sectionheader">
                <h2>OUR <span>NEWS</span></h2>
                <h3>WHAT’S UP?</h3>
            </div>
            <div class="container">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='newsproduct'>
                        <div class='newsproductthumb'><img src='<?php echo e($report->imageUrl); ?>' draggable='false'></div>
                        <div class='newsproductcontent'>
                            <h4><?php echo e($report->title); ?></h4>
                            <p>
                                <?php echo e(substr(strip_tags($report->body), 0, 300)); ?>

                                <?php echo e(strlen(strip_tags($report->body)) > 50 ? "..." : ""); ?>


                            </p>
                            <a href='<?php echo e(route('frontend.news.index.show', ['slug'=> $report->slug ])); ?>' class='newsproductmore'>VIEW MORE</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <a href="<?php echo e(route('frontend.news.index')); ?>" class="seealllink"><span>SEE ALL NEWS</span></a>
        </div>
        <div class="section footer">
            <div class="sectionheader">
                <h2><span>CONTACT</span> US</h2>
                <h3>HOW TELL TO US?</h3>
            </div>
            <div class="footercontent">
                <?php echo \App\Contact::first()->etc; ?>


            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.fullpage-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>