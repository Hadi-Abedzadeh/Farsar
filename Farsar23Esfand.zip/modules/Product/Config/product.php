<?php

return [
    'name' => 'Product'
];