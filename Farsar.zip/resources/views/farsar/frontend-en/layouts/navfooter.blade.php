<div class="footernav">
    <a href="{{ route('frontend') }}">Home</a>
    <a href="{{ route('aboutus') }}">About</a>
    <a href="{{ route('frontend.project.index') }}">Projects</a>
    <a href="{{ route('frontend.news.index') }}">News</a>
    <a href="{{ route('frontend.product.index') }}">Products</a>
    <a href="{{ route('frontend.blog.index') }}">Blog</a>
</div>
