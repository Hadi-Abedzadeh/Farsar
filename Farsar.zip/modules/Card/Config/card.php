<?php

return [
    'name' => 'Card'
];