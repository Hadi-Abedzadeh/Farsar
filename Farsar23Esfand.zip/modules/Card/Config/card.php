<?php

return [
    'name' => 'Card'
];