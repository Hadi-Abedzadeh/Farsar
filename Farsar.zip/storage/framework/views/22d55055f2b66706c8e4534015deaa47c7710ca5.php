<?php $__env->startSection('content'); ?>

    <?php switch(set_lang()):
        case ('en'): ?>
        <div class="notfound livebackground">
            <div class="container">
                <h1>404</h1>
                <h2>THIS IS NOT THE WEB PAGE YOU ARE LOOKING FOR</h2>
            </div>
        </div>
        <?php break; ?>
        <?php case ('fa'): ?>

        404444
        <?php break; ?>

    <?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>