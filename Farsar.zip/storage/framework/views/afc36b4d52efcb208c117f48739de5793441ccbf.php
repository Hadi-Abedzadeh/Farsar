<?php $__env->startSection('content'); ?>
    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-any-blog">
                <header>
                    <h2 class="c-h2">
                        <em class="f-c-b"><?php echo e($post->title); ?></em>
                    </h2>
                </header>
                <div class="row p15">
                    <div class="col-md-24">
                        <article class="art-content-any-blog">
                            <figure>
                                <img class="img-header-any-blog" src="<?php echo e($post->imageUrl); ?>" alt=""
                                     title="">
                                <img class="svg-ang-blog" src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/Anyblog.svg"
                                     alt="" title="">
                            </figure>
                            <div class="div-content-main-any-blog">

                                <?php echo $post->body; ?>


                            </div>
                            <div class="div-tag-any-blog">
                                <figure>
                                    <img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/tag-any-blog.svg" alt=""
                                         title="">
                                </figure>
                                <header>
                                    <h4 class="c-h2">برچسب ها :</h4>
                                </header>
                                <ul>
                                    <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('category', ['slug'=> $name->slug])); ?>" class="f-c-b"
                                               title="<?php echo e($name->name); ?>">#<?php echo e($name->name); ?> </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </article>
                    </div>
                </div>
            </section>
            <section class="sec-comments-any-blog">

                <article class="art-comments-any-blog">
                    <header>
                        <h4 class="c-h2">نظرات <em class="f-c-b">شما</em></h4>
                    </header>
                    <ul>
                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <header>
                                    <h5 class="f-c-b"> <?php echo e($comment->client_name); ?> </h5>
                                    <img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/stars.png" alt="" title="">
                                    <em class="c-h2"><?php echo e($comment->created_at); ?></em>
                                </header>
                                <p class="c-p">
                                    <?php echo e($comment->body); ?>

                                </p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </article>
                <footer>
                    <form action="" method="post">
                        <input type="text" placeholder="نام و نام خانوادگی">
                        <input type="text" placeholder="ایمیل شما">
                        <button class="a-btn-bgc">ثبت نظر</button>
                        <textarea name="" id="" cols="30" rows="5" placeholder="متن خود را وارد کنید …"></textarea>
                    </form>
                </footer>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    بلاگ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>