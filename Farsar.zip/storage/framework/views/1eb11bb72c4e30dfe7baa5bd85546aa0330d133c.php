<?php $__env->startSection('title'); ?>
    Edit FAQ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet m-portlet--full-height m-portlet--fit ">
        <div class="m-portlet__body">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="<?php echo e(route('faq.update', ['id'=> $faq->id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>


                <div class="form-group">
                    <label for="Title">Title</label>
                    <input type="text" name="question" class="form-control" value="<?php echo e($faq->question); ?>" id="Title" placeholder="Enter Title">
                </div>

                <div class="form-group">
                    <label for="body">body</label>
                    <textarea class="form-control" name="answer" id="body" placeholder="body"><?php echo e($faq->answer); ?></textarea>
                </div>

                <input type="hidden" name="page_id" value="<?php echo e($faq->page_id); ?>">

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <?php echo ckeditor('card', 'card-contents'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>