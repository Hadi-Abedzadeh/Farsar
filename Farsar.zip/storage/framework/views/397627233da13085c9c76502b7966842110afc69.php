<?php $__env->startSection('content'); ?>
    <style>
        button{
            background-color: red;
            color: #5f5b5b;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: right;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
            margin: 3px 0px;
            border-radius: 4px;
        }


    </style>
    <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <a href="<?php echo e(route('frontend.blog.index') .'/'.$q->slug); ?>"><?php echo e($q->title); ?></a>
            <button class="panel text-right" type="button" class="btn btn-info" data-toggle="collapse" data-target="#faq<?php echo e($q->id); ?>"> <?php echo e($q->question); ?> </button>
            <div id="faq<?php echo e($q->id); ?>" class="collapse">
                <?php echo $q->answer; ?>

            </div>
        </div>
        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>