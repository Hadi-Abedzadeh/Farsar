<?php

return [
    'name' => 'Blog'
];