<?php $__env->startSection('content'); ?>
    <main id="single-page">
        <div class="container">
            <section class="single-section">
                <div class="title">
                    <h2><span>جذب</span> نیرو</h2>
                    <div class="button"><a href="<?php echo e(route('frontend.blog.index')); ?>"><span>بازگشت به صفحه قبل</span></a>
                    </div>
                </div>
                <div class="content">
                    <div class="thumbnail">
                        <img src="<?php echo e($post->imageUrl); ?>" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>">
                    </div>
                    <div class="texts">
                        <h3><?php echo e($post->title); ?></h3>
                        <p>
                            <?php echo e($post->body); ?>

                        </p>
                    </div>
                    <br><br>
                    <hr>
                    <br><br>
                    <div class="tags">
                        <div class="title">
                            <h4>برچسب ها</h4>
                        </div>
                        <ul>
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('category', [''])); ?>"><?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </section>

            <section class="top-views">
                <div class="title">
                    <h2><span>مطالب</span> پر بازدید</h2>
                </div>
                <div class="content">
                    <div class="slider owl-carousel owl-carousel-blog owl-theme">

                        <div class="news-item">
                            <div class="img-news"><img
                                    src="/<?php echo e(env('THEME_NAME_FA')); ?>/assets/images/sample/test-img-news.png" alt=""
                                    title=""></div>
                            <div class="content-news">
                                <h3>نمایشگاه تهران</h3>
                                <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است …</p>
                                <a href="#">اطــــــــلاعــات بــیـشــــتر</a>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?>
بلاگ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-fa.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>