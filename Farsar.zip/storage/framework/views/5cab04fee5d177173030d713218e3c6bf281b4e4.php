<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="innerarea sidebyside">
            <div class="singleside">
                <h4>Project Related</h4>

                <?php $__currentLoopData = $related_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="projectitem">
                        <h3><?php echo e($project2->title); ?></h3>
                        <div class="projectitemimg">
                            <img src="<?php echo e(json_decode($project2->imageUrls)->img1); ?>" draggable="false">
                            <a href="<?php echo e(route('frontend.project.show', ['slug' => $project2->slug])); ?>" class="getmore">Get
                                Order</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="singlearea">
                <h4><?php echo e($project->title); ?></h4>
                <div class="gallerysliderarea owl-carousel">


                    <?php $__currentLoopData = json_decode($project->imageUrls, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="galleryslider active">
                            <img src="<?php echo e($img); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="content">
                    <p>
                        <?php echo e($project->body); ?>

                    </p>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>