<?php $__env->startSection('title'); ?>
    About us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet m-portlet--full-height m-portlet--fit ">
        <div class="m-portlet__body">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="<?php echo e(route('about-us.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="body">About us:</label>
                    <textarea class="form-control" name="body" id="body" placeholder="body"></textarea>
                </div>

                    
                        
                        
                    

                <button type="submit" class="btn btn-primary">Submit</button>

            </form>
        </div>
    </div>
    <?php echo ckeditor('aboutus', 'files'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>