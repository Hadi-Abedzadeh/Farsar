<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="gallerysliderarea owl-carousel">
            <div class="galleryslider"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets-en/images/slider1.jpg"></div>
            <div class="galleryslider"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets-en/images/slider2.jpg">
                <h2>Lorem Ipsum is simply dummy</h2></div>
            <div class="galleryslider"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets-en/images/slider3.jpg">
                <h2>Lorem Ipsum is simply dummy</h2></div>
        </div>
        <div class="innerarea">
            <div class="category">
                <div class="areaheader">
                    <h2>Categorys</h2>
                </div>
                <div class="categorylist">
                    <?php $__currentLoopData = $blog_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($blog_post->slug); ?>"><?php echo e($blog_post->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="content">
                <div class="areaheader">
                    <h2>News</h2>
                    <div class="sorter">
                        <div class="sorterheader">Newest</div>
                        <span>Newest</span>
                        <span>Oldest</span>
                    </div>
                </div>
                <div class="blogposts">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blogpost">
                            <div class="blogpostimg">
                                <img src="<?php echo e($report->imageUrl); ?>" draggable="false">
                            </div>
                            <div class="blogpostcontent">
                                <h4><?php echo e($report->title); ?></h4>
                                <p>
                                    <?php echo e(substr(strip_tags($report->body), 0, 100)); ?>

                                    <?php echo e(strlen(strip_tags($report->body)) > 50 ? "..." : ""); ?>

                                </p>
                                <a href="<?php echo e(route('frontend.news.index.show', ['slug' => $report->slug ])); ?>" class="more">See More</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <?php echo e($news->links()); ?>

                
                
                
                
                
                
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?>
    News
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>