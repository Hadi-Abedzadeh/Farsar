<?php $__env->startSection('content'); ?>

    <div class="newsproductarea">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="newsproduct">
                <div class="newsproductthumb">
                    <img src="<?php echo e($report->imgUrl); ?>" draggable="false">
                </div>
                <div class="newsproductcontent">
                    <h4><?php echo e($report->title); ?></h4>
                    <p><?php echo e($report->body); ?></p>
                    <a href="<?php echo e($report->slug); ?>" class="newsproductmore">VIEW MORE</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>