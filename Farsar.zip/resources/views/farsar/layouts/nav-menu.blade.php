<ul>
    <li><a href="{{ route('frontend') }}" title="خانه">خانه</a></li>
    <li><a href="{{ route('aboutus') }}" title="درباره ما">درباره ما</a></li>
    <li><a href="{{ route('frontend.news.index') }}" title="اخبار">اخبار</a></li>
    <li><a href="{{ route('frontend.product.index') }}" title="محصولات">محصولات</a></li>
    <li><a href="{{ route('frontend.project.index') }}" title="پروژه ها">پروژه ها</a></li>
    <li><a href="{{ route('frontend.blog.index') }}" title="بلاگ">بلاگ</a></li>
    <li><a href="{{ route('catalog') }}" title="کاتالوگ">کاتالوگ</a></li>
    <li><a href="{{ route('contactus') }}" title="تماس با ما">تماس با ما</a></li>
</ul>
