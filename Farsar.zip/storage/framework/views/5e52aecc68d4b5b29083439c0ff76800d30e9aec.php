<div id="fullmenu">
    <div class="fullmenulink">
        <a href="<?php echo e(route('frontend')); ?>">صفحه اصلی</a>
        <a href="<?php echo e(route('frontend.about.index')); ?>">درباره ما</a>
        <a href="<?php echo e(route('catalog')); ?>">کاتالوگ</a>
        <a href="<?php echo e(route('frontend.product.index')); ?>">محصولات</a>
        <a href="<?php echo e(route('frontend.blog.index')); ?>">بلاگ</a>
        <a href="<?php echo e(route('frontend.news.index')); ?>">اخبار</a>
        <a href="<?php echo e(route('frontend.contact-us.index')); ?>">تماس با ما</a>
    </div>
    <div class="fullmenucircle1"></div>
    <div class="fullmenucircle2"></div>
</div>
