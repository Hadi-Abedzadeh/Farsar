<?php $__env->startSection('content'); ?>
    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-catalog">
                <header>
                    <h2 class="c-h2">
                        آگهی <em class="f-c-b">استخدام</em>
                    </h2>
                </header>

                <div class="div-content-career" itemscope itemtype="http://schema.org/options" data-tabindex="career">
                    <header class="tab-title header-career">
                        <ul>
                            <li data-tab="all" class="bg-li-career-before"><span class="c-h2">همه</span></li>
                            <li data-tab="2" class="bg-li-career-before"><span class="c-h2">برنامه نویسی</span></li>
                            <li data-tab="3" class="bg-li-career-before"><span class="c-h2">گرافیک</span></li>
                            <li data-tab="4" class="bg-li-career-before"><span class="c-h2">فروش</span></li>
                            <li data-tab="5" class="bg-li-career-before"><span class="c-h2">بازاریابی</span></li>
                            <li data-tab="6" class="bg-li-career-before"><span class="c-h2">مهندسی</span></li>
                        </ul>
                    </header>

                    <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row p15" data-tabc="<?php echo e($career->part_id); ?>">
                            <div class="col-md-12">
                                <article class="art-content-career">
                                    <a href="javascript:void(0)" class="bdi-bg-c" title="واحد برنامه نویسی">
                                        <?php echo e($career->unit); ?>

                                    </a>
                                    <header>
                                        <h3 class="c-h2">
                                            <a href="javascript:void(0)" title="">
                                                <?php echo e($career->position); ?>

                                            </a>
                                        </h3>
                                        <ul>
                                            <li><span class="f-c-b"><?php echo e($career->etc); ?></span></li>
                                        </ul>
                                    </header>
                                </article>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>