<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="innerarea sidebyside">
            <div class="singleside">
                <h4>Project Related</h4>

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="projectitem">
                        <h3><?php echo e($project->title); ?></h3>
                        <div class="projectitemimg">
                            <img src="<?php echo e(json_decode($project->imageUrls)->img1); ?>" draggable="false">
                            <a href="<?php echo e(route('frontend.project.show', ['slug' => $project->slug])); ?>" class="getmore">Get Order</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="singlearea">
                <h4><?php echo e($news->title); ?></h4>
                
                        
                            
                        
                

                <img src="<?php echo e($news->imageUrl); ?>">


                <div class="content">
                    <p>
                        <?php echo e($news->body); ?>

                    </p>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    News
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>