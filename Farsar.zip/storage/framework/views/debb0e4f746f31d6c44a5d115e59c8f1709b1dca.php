<?php $__env->startSection('content'); ?>

    <div class="m-portlet m-portlet--full-height m-portlet--fit ">
        <div class="m-portlet__body">
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="Title">Title</label>
                    <input type="text" name="title" class="form-control" id="Title" value="<?php echo e($blog_post->title); ?>" placeholder="Enter Title">
                </div>

                <div class="form-group">
                    <label for="body">body</label>
                    <textarea class="form-control" name="body" id="body" placeholder="body"><?php echo e($blog_post->body); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="category">Category</label>
                    <select class="form-control js-example-basic-multiple" id="category" name="category[]" multiple="multiple">
                        <option value="AL">Alabama</option>
                        <option value="AL">Alabama</option>
                        <option value="AL">Alabama</option>
                        <option value="AL">Alabama</option>
                        <option value="AL">Alabama</option>
                        <option value="WY">Wyoming</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="Title">Upload image</label>
                    <input type="file" name="imageUrl" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <script src="/assets/ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('body');
    </script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('select2'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Edit post
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>