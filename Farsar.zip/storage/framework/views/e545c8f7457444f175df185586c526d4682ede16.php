<?php $__env->startSection('content'); ?>

    <div class="newsproductarea">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="newsproduct">
                <div class="newsproductthumb"><img src="<?php echo e(json_decode($product->imageUrls)->img1); ?>" draggable="false">
                </div>
                <div class="newsproductcontent">
                    <h4><?php echo e($product->title); ?></h4>
                    <p>
                        <?php echo e(substr(strip_tags($product->body), 0, 500)); ?>

                        <?php echo e(strlen(strip_tags($product->body)) > 50 ? "..." : ""); ?>

                    </p>
                    <a href="<?php echo e(route('frontend.product.show',['slug'=>$product->slug])); ?>" class="newsproductmore">VIEW
                        MORE</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>