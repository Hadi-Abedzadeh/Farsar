@extends('default.layouts.frontend')

@section('content')
    <div class="container-fluid">
        <h2>Home</h2>
        {{ create_box(1) }}
    </div>
@endsection
