<?php $__env->startSection('content'); ?>
    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-catalog">
                <header>
                    <h2 class="c-h2">
                        دسته بندی <em class="f-c-b">محصولات</em>
                    </h2>
                </header>
                <div class="row p15">
                    <div class="col-md-18">
                        <div class="row p15">

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-8">
                                    <article class="art-content-sider art-content-sider-any art-content-sider-products">
                                        <div>
                                            <figure>
                                                <img src="<?php echo e(json_decode($product->imageUrls)->img1); ?>" alt="<?php echo e($product->title); ?>" title="<?php echo e($product->title); ?>">
                                            </figure>
                                        </div>
                                        <header>
                                            <h3 class="c-h2"><?php echo e($product->title); ?></h3>
                                        </header>
                                        <a class="a-btn-bggr a-btn" href="<?php echo e(route('frontend.product.show', ['slug' => $product->slug])); ?>" title="مشاهده محصول">مشاهدهمحصول</a>
                                    </article>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <aside>
                            <article class="art-aside">
                                <header>
                                    <figure>
                                        <img src="./assets/images/sample/sidebar.svg" alt="" title="">
                                    </figure>
                                    <h3 class="f-c-b">
                                        دسته بندی محصولات
                                        <em class="c-h2">دسته بندی مورد نظر را انتخاب کنید</em>
                                    </h3>
                                </header>
                                <ul class="ul-art-aside">
                                    <?php $__currentLoopData = $get_products_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('frontend.product.catalog',['slug' => $produc->slug ])); ?>" class="c86" title="<?php echo e($produc->title); ?>"> <?php echo e($produc->title); ?> </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </article>
                        </aside>
                    </div>
                </div>
            </section>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    محصولات
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>