<?php

return [
    'name' => 'Faq'
];