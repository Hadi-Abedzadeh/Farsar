<?php $__env->startSection('content'); ?>

    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-catalog">
                <header>
                    <h2 class="c-h2">
                        دسته بندی <em class="f-c-b">محصولات</em>
                    </h2>
                </header>
                <div class="row p15">
                    <div class="col-md-18">
                        <div class="row p15">

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-8">
                                    <article class="art-content-sider art-content-sider-any art-content-sider-products">
                                        <div>
                                            <figure>
                                                <img src="<?php echo e($product->imageUrl); ?>" alt="<?php echo e($product->title); ?>" title="<?php echo e($product->title); ?>">
                                            </figure>
                                        </div>
                                        <header>
                                            <h3 class="c-h2"><?php echo e($product->title); ?></h3>
                                        </header>
                                        <a class="a-btn-bggr a-btn" href="<?php echo e(route('frontend.product.catalog', ['slug' => $product->slug])); ?>" title="مشاهده محصول">مشاهدهمحصول</a>
                                    </article>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <aside>
                            <article class="art-aside">
                                <header>
                                    <figure>
                                        <img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/sample/sidebar.svg" alt="" title="">
                                    </figure>
                                    <h3 class="f-c-b">
                                        عنوان بلاگ
                                        <em class="c-h2">زیر عنوان بلاک مورد نظر</em>
                                    </h3>
                                </header>
                                <ul class="ul-art-aside">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('frontend.blog.index.slug', ['slug'=>$post->slug])); ?>" class="c86" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </article>
                        </aside>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    محصولات
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>