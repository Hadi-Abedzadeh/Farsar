<header>
    <div class="left">
        <a class="logo" href="<?php echo e(route('frontend')); ?>"></a>
        <h1>Products</h1>
    </div>
    <div class="right">
        <div class="socialmedias">
            <a href="#" class="icon googleplus"></a>
            <a href="#" class="icon telegram"></a>
            <a href="#" class="icon twitter"></a>
            <a href="#" class="icon instagram"></a>
        </div>
        <div class="searchbox">
            <input type="text" placeholder="Search...">
            <div class="searchbutton"></div>
        </div>
    </div>
</header>
