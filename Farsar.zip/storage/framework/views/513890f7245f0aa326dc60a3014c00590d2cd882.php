<?php $__env->startSection('content'); ?>
    <div class="div-list-project">
        <div class="container">
            <section class="sect-slider-content-project sect-slider-content-catalog">
                <header>
                    <h2 class="c-h2">
                        دانلود <em class="f-c-b">کاتالوگ</em>
                    </h2>
                </header>
                <div class="row p15">

                    <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-8">
                            <article class="art-content-cataloge">
                                <a href="<?php echo e($catalog->url); ?>" title=""></a>
                                <div class="bdi-down bdi-bg-c">
                                    <i class="icon-layers"></i>
                                </div>
                                <h3 class="c-h2"><?php echo e($catalog->title_fa); ?></h3>
                                <bdi class="bdi-bookmark f-c-b">
                                    <i class="icon-bookmark">
                                        <em>فارسی</em>
                                    </i>
                                </bdi>
                            </article>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    کاتالوگ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>