<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="well ">
            <?php if(file_exists(($post->imageUrl))): ?>
                <img src="/<?php echo e($post->imageUrl); ?>"
                     style="width: 100%; height: 300px; border-radius: 2px">
            <?php else: ?>
                <img src="/uploads/no-image.png" style="width: 100%; height: 300px; border-radius: 2px">
            <?php endif; ?>
            <br>

            <h2><a href="<?php echo e(route('frontend.blog.index') .'/'.$post->slug); ?>"><?php echo e($post->title); ?></a></h2>
            <br>
            <?php echo str_limit(strip_tags($post->body), 300); ?>

            <?php echo (strlen(strip_tags($post->body)) > 300) ? ' ...... ' : ''; ?>

            <br>
            <hr>

            <?php if(count($post->categories()->get())): ?>
                <ul>Category:
                    <?php $__currentLoopData = $post->categories()->pluck('name', 'slug'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('category', ['categorySlug' => $slug])); ?>"> <?php echo e($category); ?> </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <?php echo e("No category"); ?>

            <?php endif; ?>
            <hr>
        </div>

        <?php $__currentLoopData = $post->comments()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comment->active == 1): ?>
                <hr>
                Name:  <?php echo e($comment->client_name); ?><br>
                Email: <?php echo e($comment->client_email); ?> <br>
                Body:  <?php echo $comment->body; ?> <br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <hr>

        <div class="container">
            <div class="col-lg-6 well">
                <form action="<?php echo e(route('backend.blog.comments.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                    <div class="form-group">
                        <label for="name">Name: </label>
                        <input type="text" name="client_name" class="form-control" id="name">
                    </div>

                    <div class="form-group">
                        <label for="name">Email: </label>
                        <input type="text" name="client_email" class="form-control" id="email">
                    </div>

                        <div class="form-group">
                            <label for="comment">Comment</label>
                            <textarea class="form-control" style="resize: vertical; min-height: 100px;" name="body" id="comment" placeholder="comment"></textarea>
                        </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>