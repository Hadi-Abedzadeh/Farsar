<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h2>Home</h2>
        <?php echo e(create_box(1)); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>