<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="about">
        <h3>About</h3>
        <p>
            <?php echo e($about->body); ?>


        </p>
    </div>
</div>

    <?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>