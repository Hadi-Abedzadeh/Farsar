<!doctype html>
<html class="areapage">
<head>
    <meta charset="utf-8">
    <title>SFM | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/latest/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/latest/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/animate.css" type="text/css" media="screen">
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/owl.carousel.min.css" type="text/css" media="screen">
    <link rel="stylesheet" href="/<?php echo e(env('THEME_NAME')); ?>/assets/css/style.css" type="text/css" media="screen">
</head>
<body>
<nav>
    <a class="logo" href="#"></a>
    <div class="menu noselect">
        <div class="menu-text"><span>MENU</span><span>CLOSE</span></div>
        <div class="menu-icon">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="background"></div>
</nav>
<div id="fullmenu">
    <div class="fullmenulink">
        <a href="<?php echo e(route('frontend.about.index')); ?>">ABOUT</a>
        <a href="<?php echo e(route('catalog')); ?>">CATALOGE</a>
        <a href="<?php echo e(route('frontend.product.index')); ?>">PRODUCT</a>
        <a href="<?php echo e(route('frontend.blog.index')); ?>">BLOG</a>
        <a href="<?php echo e(route('frontend.news.index')); ?>">NEWS</a>
        <a href="<?php echo e(route('frontend.contact-us.index')); ?>">CONTACT</a>
    </div>
    <div class="fullmenusquare1"></div>
    <div class="fullmenusquare2"></div>
</div>


        <?php echo $__env->yieldContent('content'); ?>
    </div>
    </div>
<footer>
    <div class="footercontent">
        <?php echo \App\Contact::first()->etc; ?>

    </div>
</footer>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="/<?php echo e(env('THEME_NAME')); ?>/assets/js/plugin.js"></script>
<?php echo $__env->yieldContent('infiniteScroll'); ?>
</body>
</html>
