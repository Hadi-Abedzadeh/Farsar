<?php $__env->startSection('content'); ?>
    <div class="innerarea">
    <div class="projectlist">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="fullproject">
            <div class="fullprojectimg">
                <img src="<?php echo e(json_decode($project->imageUrls)->img1); ?>">
                <a href="<?php echo e(route('frontend.project.show', ['slug' => $project->slug])); ?>" class="more">See More</a>
            </div>
            <div class="fullprojectside">
                <h3><?php echo e($project->title); ?></h3>
                <div class="fullprojectconent">
                    <p>
                        <?php echo e(substr(strip_tags($project->body), 0, 400)); ?>

                        <?php echo e(strlen(strip_tags($project->body)) > 50 ? "..." : ""); ?>


                    </p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($projects->links()); ?>


            
            
            
            
            
            
        
    </div>
</div>

    <?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-en.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>