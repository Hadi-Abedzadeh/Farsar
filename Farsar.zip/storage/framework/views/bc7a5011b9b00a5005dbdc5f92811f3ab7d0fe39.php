<script src="/assets/ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace('body',{
        filebrowserUploadMethod : 'form',
        filebrowserUploadUrl: '/backend/upload-image/<?php echo e($module_name); ?>/<?php echo e($folder_name); ?>/?',
        filebrowserImageUploadUrl: '/backend/upload-image/<?php echo e($module_name); ?>/<?php echo e($folder_name); ?>/?'
    });
</script>
